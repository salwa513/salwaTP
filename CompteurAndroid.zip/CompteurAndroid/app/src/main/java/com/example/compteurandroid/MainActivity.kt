package com.example.compteurandroid

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    var compteur = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        val textViewCompteur = findViewById<TextView>(R.id.textViewCompteur)

        val buttonIncrementer = findViewById<Button>(R.id.bouton_incrementer)

        val buttonDecrementer = findViewById<Button>(R.id.bouton_decrementer)

        val buttonReinitialiser = findViewById<Button>(R.id.buttonReinitialiser)
        buttonIncrementer.setOnClickListener {

            compteur = compteur - 1

            textViewCompteur.text = compteur.toString()
        }
        buttonDecrementer.setOnClickListener {

            compteur = compteur + 1

            textViewCompteur.text = compteur.toString()
        }
        buttonReinitialiser.setOnClickListener {

            compteur = 0

            textViewCompteur.text = compteur.toString()
        }
    }
}
